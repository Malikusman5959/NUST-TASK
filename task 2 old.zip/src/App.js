import React, { useState, useEffect } from "react";
import "./style.css";
import Feeds from "./components/Feeds"


function App() {

  return (
   <div>
<Feeds/>
   </div>
  );
}

export default App;
