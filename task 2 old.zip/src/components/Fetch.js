import axios from "axios";

export const fetchFeeds = (orderData) => {
    try {
        //   let res = await axios.get(`https://dwinnex.com/feed/`);
        let res = '<?xml version=”1.0" encoding=”UTF-8"?>' +
            '<Student>' +
            '<PersonalInformation>' +
            '<FirstName>Sravan</FirstName>' +
            '<LastName>Kumar</LastName>' +
            '<Gender>Male</Gender>' +
            '</PersonalInformation>' +
            '<PersonalInformation>' +
            '<FirstName>Sudheer</FirstName>' +
            '<LastName>Bandlamudi</LastName>' +
            '<Gender>Male</Gender>' +
            '</PersonalInformation>' +
            '</Student>';
        return res;
    } catch (error) {
        console.log(error);
    }
};
