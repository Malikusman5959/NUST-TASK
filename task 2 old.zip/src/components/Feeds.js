import React from 'react'
import { useState } from 'react'
import { useEffect } from 'react'
import { fetchFeeds } from './Fetch'
import fs from "fs"; 
import { parseString } from "xml2js"; 

function Feeds() {

    const [feeds, setfeeds] = useState('No feeds');

    useEffect(() => {

        var xml = fetchFeeds();
        var json = {}
        parseString(xml, function (err, results) {
            // parsing to json
             json = JSON.stringify(results);
        });

        setfeeds(json);

    }, [])

    useEffect(() => {

        console.log(feeds);

    }, [feeds])

    return (
        <div>
            {feeds}
        </div>
    )
}

export default Feeds















